"""
Reproduces the exact scenario from the design doc's Phase 5:

    Region 1 (station A):
        Humidity: 95%
        Pressure: falling
        Wind: increasing
        Rainfall: beginning
    Neighbors: normal

Expected: Agent2 should say "possible localized event", NOT "sensor faulty".
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from datetime import datetime, timedelta
from agent2 import Agent2, StationReading, Coordinates


def mk(station, t, temp, hum, pres, wind, wdir, rain=0.0, lat=19.07, lon=72.87):
    return StationReading(station, t, Coordinates(lat, lon), temp, hum, pres, wind, wdir, rain)


def main():
    agent = Agent2()
    t = datetime(2026, 7, 15, 14, 0)

    # Station A's own recent trend: humidity climbing, pressure falling,
    # wind picking up, rain just starting -- a consistent build-up, not a spike.
    history = [
        mk("A", t - timedelta(minutes=20), 29.0, 70, 1006.0, 4.0, 210, 0.0),
        mk("A", t - timedelta(minutes=15), 28.6, 78, 1005.4, 5.5, 212, 0.5),
        mk("A", t - timedelta(minutes=10), 28.2, 85, 1004.7, 7.0, 214, 2.0),
        mk("A", t - timedelta(minutes=5), 27.8, 90, 1004.0, 8.5, 216, 4.0),
    ]
    current = mk("A", t, 27.5, 95, 1003.2, 10.0, 218, 6.5)

    neighbors = [
        mk("B", t, 33.0, 55, 1008.5, 3.0, 180),
        mk("C", t, 34.0, 52, 1008.7, 3.2, 178),
        mk("D", t, 33.5, 54, 1008.6, 2.8, 182),
        mk("E", t, 34.2, 53, 1008.4, 3.1, 179),
    ]

    report = agent.evaluate(current, neighbors, history)

    print("=" * 70)
    print(f"Station {report.station_id} @ {report.timestamp}")
    print("=" * 70)
    print(f"PHYSICAL  = {report.physical.status}")
    print(f"SPATIAL   = {report.spatial.status}  (deviating: {report.spatial.deviating_variables})")
    print(f"TEMPORAL  = {report.temporal.status}")
    print(f"REASONING = {report.reasoning.verdict}")
    print(f"          {report.reasoning.explanation}")
    print(f"SCORE     = {report.score.total}/100  -> {report.final_label}")
    print()
    print("Full JSON report:")
    print(json.dumps(report.to_dict(), indent=2))


if __name__ == "__main__":
    main()
